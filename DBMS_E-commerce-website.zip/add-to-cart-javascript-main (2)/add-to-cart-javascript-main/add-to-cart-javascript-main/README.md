
# Simple add to cart using javascript with localstorage


Create an Add to cart using javascript with localstorage, filter & search functionality.




## Demo

Tutorial : https://dev.to/rajamanickam/add-to-cart-using-javascript-3nom

Demo : https://github.com/erajamanickam/add-to-cart-javascript

Youtube : https://youtu.be/UPyNp-SVV4M





## Tech Stack

Javascript


## Screenshots

Preview :

![App Screenshot](https://res.cloudinary.com/practicaldev/image/fetch/s--YgZX0o4D--/c_imagga_scale,f_auto,fl_progressive,h_420,q_auto,w_1000/https://dev-to-uploads.s3.amazonaws.com/uploads/articles/zqyb9et5btgjk8ikthpi.png)



const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const app = express();
const cors = require("cors");
var bodyParser = require("body-parser");
const port = 8000;

app.use(cors());
app.use(
  bodyParser.urlencoded({
    extended: false,
  })
);
app.use(express.json());

const db = new sqlite3.Database("shopping_cart.db");

db.serialize(() => {
  db.run(
    "CREATE TABLE IF NOT EXISTS cart (id INTEGER PRIMARY KEY, name TEXT, price REAL)"
  );
});

app.use(express.json());

app.use(express.static("./public"));
app.get("/", (req, res) => {
  res.sendFile("index.html", { root: __dirname + "/public" });
});

//  route for adding items to the cart
app.route("/api/cart/add").post((req, res) => {
  const { name, price } = req.body;
  console.log(req.body);
  db.run(
    "INSERT INTO cart (name, price) VALUES (?,?)",
    [name, price],
    (err) => {
      if (err) {
        res.status(500).json({ error: err.message });
        return;
      }
      res.status(200).json({ message: "Item added to the cart." });
    }
  );
});

// route for getting cart items
app.route("/api/cart/get").get((req, res) => {
  db.all("SELECT * FROM cart", (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.status(200).json(rows);
  });
});

app.listen(port, () => {
  console.log("Server is running on port " + port);
});

app.route("/api/cart/remove").delete((req, res) => {
  const { name } = req.body;
  const sql = `DELETE FROM cart WHERE name = ${name}`;
  db.run(sql, (err) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.status(200).json({ message: "Product has been removed from the cart" });
  });
});

app.route("/api/cart/removeAll").delete((req, res) => {
  const { name } = req.body;
  const sql = `DELETE FROM cart`;
  db.run(sql, (err) => {
    if (err) {
      res.status(500).json({ error: err.message });
      return;
    }
    res.status(200).json({ message: "DB CLean" });
  });
});
